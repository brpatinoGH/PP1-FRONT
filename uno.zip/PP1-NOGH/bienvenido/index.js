document.getElementById("btn iniciosesion").addEventListener("click", function() {
    window.location.href = "inicio-sesion.html"; // Cambia a la URL de tu pantalla de inicio de sesión
});
