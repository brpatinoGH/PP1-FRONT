function obtenerFechaYDia() {
    const fecha = new Date();
    const dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    const numeroDia = fecha.getDate(); // Número del día del mes
    const nombreDia = dias[fecha.getDay()]; // Nombre del día de la semana
    const opcionesMes = { month: 'long' };
    const mesFormateado = fecha.toLocaleDateString('es-ES', opcionesMes);
    // Mostrar el mes en el elemento con id "mes"
    document.getElementById('mes').textContent = mesFormateado;
    let mesPrimeraMayuscula=(mesFormateado.charAt(0)).toUpperCase() + mesFormateado.slice(1,mesFormateado.length)
    document.getElementById('mes-2').textContent = mesPrimeraMayuscula;
    document.getElementById('numero-dia').textContent = numeroDia;
    document.getElementById('nombre-dia').textContent = nombreDia;

}

window.onload = obtenerFechaYDia;